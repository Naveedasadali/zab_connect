<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">

    <title>SZABIST Connect - Events</title>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="zab connect">SZABIST Connect</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
            <a class="nav-link" href="{{ route('zabconnect') }}">Home</a>
<a class="nav-link" href="{{ route('events') }}">Events</a>
<a class="nav-link" href="{{ route('contact') }}">Contact</a>

            </div>
            <div class="ml-auto">
                <a class="btn btn-dark" href="admin_login" role="button">Admin Login</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <h1 class="text-center my-5">Szabist Student Council Events</h1>
        <div class="event-cards">
            <div class="card mb-4">
                <img src="https://docs.szabist.edu.pk/websites/images/Photo%20Gallery/2023/September/Comedy%20night/02.jpg" class="card-img-top" alt="Event 1">
                <div class="card-body">
                    <h5 class="card-title">COMEDY NIGHT</h5>
                    <p class="card-text">  You can run, but you can’t escape the laughs! The wait is finally over, 2 days to Comedy Night. 😸<br>
                        🗓️ : 19th October, Saturday<br>
                        ⏰ : 6:00 PM - Onwards<br>
                        📍 : 100 Courtyard, SZABIST<br>
                        🎟️ : Students: 600/- || Alumni: 1000/-.</p>
                </div>
            </div>

            <div class="card mb-4">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRsyAWTfRAXbthGSnyLFP9eRcdX6UVyIfsw-Q&s.jpg" class="card-img-top" alt="Event 2">
                <div class="card-body">
                    <h5 class="card-title">FUNKAR FEST</h5>
                    <p class="card-text">A celebration of the arts, and Shugal Mela, an ode to community spirit, lit up Welcome Week with creativity, care, and lasting moments! Huge shoutout to the Arts & Culture and Community Service pillars for pulling off their incredible events ✨.</p>
                </div>
            </div>

            <div class="card mb-4">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0HTE4fFcSsImtc3MhkDAIYQRfrmPfzVeGlQ&s.jpg" class="card-img-top" alt="Event 3">
                <div class="card-body">
                    <h5 class="card-title">POWER PLAY</h5>
                    <p class="card-text">Power Play had the field on fire while Cyber Clash lit up the screens! <br> ⚽🎮 Whether you were scoring goals online or offline, freshers brought nothing but energy and skills.</p>
                </div>
            </div>

            <div class="card mb-4">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPS_gceyYOqYHq_SQr7MOfIDvkCwZCbc74Rw&s.jpg" class="card-img-top" alt="Event 4">
                <div class="card-body">
                    <h5 class="card-title">FallFrenzyWeek</h5>
                    <p class="card-text">Announcing our diverse vendors’ lineup for Fall Frenzy Week! 📣 We’ve got art, dessert, jewellery and more! Be sure to stop by, explore, and grab something special. See you all there! ✨.</p>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center mt-5">
        <p>©2024 SZABIST Connect</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
