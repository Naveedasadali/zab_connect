<!doctype html>
<html lang="en">
<head>
    <!-- Meta tags and CSS links omitted for brevity -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">

    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cedarville+Cursive&display=swap" rel="stylesheet">

    <title>SZABIST Connect - Home</title>
</head>
<body>

    <header class="site-header"> <!-- Updated header class -->
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand" href="index.html">SZABIST Connect</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                <a class="nav-link" href="{{ route('zabconnect') }}">Home</a>
<a class="nav-link" href="{{ route('events') }}">Events</a>
<a class="nav-link" href="{{ route('contact') }}">Contact</a>

                </div>
                <div class="ml-auto">
                    <a class="btn btn-dark" href="admin_login" role="button">Admin Login</a>
                </div>
            </div>
        </nav>
    </header>
    
    

    <!-- Main Content for Home Page -->
    <div class="jumbotron text-center">
        <h1 class="display-5">Welcome to SZABIST Connect</h1>
        <p class="lead">Find all the latest SZABIST events here!</p>
        <a class="btn btn-dark btn-lg" href="events" role="button">View Events</a>
    </div>

    <!-- Latest Event Details Section -->
    <div class="container mt-4">
        <h3 class="text-center">Latest Events</h3>
        <div class="row">
            <!-- Event 1 -->
            <div class="col-md-3">
                <div class="card">
                    <img src="https://docs.szabist.edu.pk/websites/images/Photo%20Gallery/2023/September/Comedy%20night/02.jpg" class="card-img-top" alt="Event 1">
                    <div class="card-body">
                        <h5 class="card-title">COMEDY NIGHT</h5>
                        <p class="card-text">
                            You can run, but you can’t escape the laughs! The wait is finally over, 2 days to Comedy Night. 😸<br>
                            🗓️ : 19th October, Saturday<br>
                            ⏰ : 6:00 PM - Onwards<br>
                            📍 : 100 Courtyard, SZABIST<br>
                            🎟️ : Students: 600/- || Alumni: 1000/-
                        </p>
                        
                    </div>
                </div>
            </div>
            <!-- Event 2 -->
            <div class="col-md-3">
                <div class="card">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRsyAWTfRAXbthGSnyLFP9eRcdX6UVyIfsw-Q&s.jpg" class="card-img-top" alt="Event 2">
                    <div class="card-body">
                        <h5 class="card-title">FUNKAAR FEST</h5>
                        <p class="card-text"> A celebration of the arts, and Shugal Mela, an ode to community spirit, lit up Welcome Week with creativity, care, and lasting moments! Huge shoutout to the Arts & Culture and Community Service pillars for pulling off their incredible events ✨.</p>
                    </div>
                </div>
            </div>
            <!-- Event 3 -->
            <div class="col-md-3">
                <div class="card">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0HTE4fFcSsImtc3MhkDAIYQRfrmPfzVeGlQ&s.jpg" class="card-img-top" alt="Event 3">
                    <div class="card-body">
                        <h5 class="card-title">POWER PLAY</h5>
                        <p class="card-text">Power Play had the field on fire while Cyber Clash lit up the screens! <br> ⚽🎮 Whether you were scoring goals online or offline, freshers brought nothing but energy and skills.
                            ..</p>
                    </div>
                </div>
            </div>
            <!-- Event 4 -->
            <div class="col-md-3">
                <div class="card">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPS_gceyYOqYHq_SQr7MOfIDvkCwZCbc74Rw&s.jpg" class="card-img-top" alt="Event 4">
                    <div class="card-body">
                        <h5 class="card-title">FallFrenzyWeek </h5>
                        <p class="card-text">Announcing our diverse vendors’ lineup for Fall Frenzy Week! 📣 We’ve got art, dessert, jewellery and more! Be sure to stop by, explore, and grab something special. See you all there! ✨.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Ticket and Location Section -->
    <div class="container mt-5">
        <hr>
        <div class="cta text-center">
            <h1>Get Your Ticket Today!</h1>
            <p>Szabist 100 Campus</p>
            <a class="btn btn-dark btn-lg" href="#" role="button">BUY TICKET PKR 1000</a>
        </div>
        <hr>
        <div class="venue row">
            <div class="col-md-6 venue-section">
                <h3>The Venue</h3>
                <p>Our event will be held at <strong>SZABIST 100 Campus, Karachi</strong></p>
                <div class="mapouter">
                    <div class="gmap_canvas">
                        <iframe width="100%" height="300" src="https://maps.google.com/maps?q=SZABIST%20100%20Campus,%20Karachi&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no"></iframe>
                    </div>
                </div>
            </div>
            <div class="col-md-6 venue-section">
                <img class="venue-img" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTREcHmYJQ1zxqOiokaDcknEQ8e8Ovbt33HUg&s.jpg" alt="SZABIST Campus Image" style="width: 100%; height: auto;">
            </div>
        </div>
    </div>

    <!-- Footer with Social Media Icons -->
    <footer class="text-center mt-4">
        <span class="icon">
            <i class="fab fa-twitter"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-facebook-square"></i>
        </span>
        <p>©2023 SZABIST Connect</p>
    </footer>

    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/497162a0b5.js" crossorigin="anonymous"></script>

    <!-- Optional JavaScript and Bootstrap Bundle -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

</body>
</html>
