<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">

    <title>SZABIST Connect - Admin Login</title>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="zab connect.html">SZABIST Connect</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
            <a class="nav-link" href="{{ route('zabconnect') }}">Home</a>
<a class="nav-link" href="{{ route('events') }}">Events</a>
<a class="nav-link" href="{{ route('contact') }}">Contact</a>

            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Admin Login</h1>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form onsubmit="return validateForm()" action="admin_dashboard.html" method="POST">
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-dark btn-block">Login</button>
                </form>
                <p id="error-message" class="text-danger text-center mt-3"></p>
            </div>
        </div>
    </div>

    <footer class="text-center mt-5">
        <p>©2024 SZABIST Connect</p>
    </footer>

    <script>
        function validateForm() {
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            const errorMessage = document.getElementById("error-message");

            const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailPattern.test(email)) {
                errorMessage.textContent = "Please enter a valid email address.";
                return false;
            }

            if (password.length < 6) {
                errorMessage.textContent = "Password must be at least 6 characters long.";
                return false;
            }

            // If validation passes
            errorMessage.textContent = "";
            return true;
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
