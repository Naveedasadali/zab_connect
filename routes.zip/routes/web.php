<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});
Route::get('/', function () {
    return view('zabconnect');
})->name('zabconnect'); // Home route

Route::get('/events', function () {
    return view('events');
})->name('events'); // Named route for events

Route::get('/contact', function () {
    return view('contact');
})->name('contact'); // Named route for contact

Route::get('/admin_login', function () {
    return view('admin_login');
})->name('admin_login'); // Named route for admin login



require __DIR__.'/auth.php';
